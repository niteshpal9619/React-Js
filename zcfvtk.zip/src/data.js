let videos = [
  {
    id: 1,
    views: "10K",
    channel: "Coder Dost1",
    title: "React Js tutorial",
    time: "2 Month Ago",
    varified: true
  },
  {
    id: 2,
    views: "11M",
    channel: "Codding Nenja",
    title: "Node Js tutorial",
    time: "1 Month Ago",
    varified: false
  },
  {
    id: 3,
    views: "110K",
    channel: "Noder",
    title: "Mongo DB tutorial",
    time: "1 Month Ago",
    varified: false
  }
];

export default videos;
