import Video from "./Video";
import videos from "./data";
import "./App.css";

function App() {
  return (
    <div className="App">
      <div>videos</div>
      {videos.map((item) => (
        <Video
          key={item.id}
          title={item.title}
          channel={item.channel}
          time={item.time}
          views={item.views}
          varified={item.varified}
        ></Video>
      ))}
    </div>
  );
}

export default App;
