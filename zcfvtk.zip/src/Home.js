function Home() {
  return (
    <div>
      <h6>this is Home Components</h6>
    </div>
  );
}

export default Home;
