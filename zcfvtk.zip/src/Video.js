import "./Video.css";

function Video({ title, channel, views, time, varified }) {
  let channelJsx;
  // if (varified) {
  //   channelJsx = <div className="channel">{channel}✅</div>;
  // } else {
  //   channelJsx = <div className="channel">{channel}</div>;
  // }
  return (
    <>
      <div className="container">
        <div className="pic"></div>
        <img src="https://loremflickr.com/140/90" />
        <div className="title">{title}</div>
        <div className="channel">
          {channel}
          {varified ? "✅" : null}
        </div>
        <div className="view">
          {views} views<span>.</span>
          {time}
        </div>
      </div>
    </>
  );
}

export default Video;
