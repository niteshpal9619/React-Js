import "./Card.css";

function Card({ Header, Content, Footer }) {
  function CallDetails() {
    console.log("My name is:" + Footer);
  }
  return (
    <div>
      <div className="card">
        <div className="card-header">{Header}</div>
        <div className="card-body">
          <img src={Content} alt="logo" />
        </div>
        <div className="card-footer">{Footer}</div>
        <br />
        <div className="card-footer">Architect & Engineer</div>
        <div className="ButtonPos">
          <button className="button" onClick={CallDetails}>
            Show Me
          </button>
        </div>
      </div>
    </div>
  );
}

export default Card;
