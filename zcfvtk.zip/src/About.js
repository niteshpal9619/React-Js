function About() {
  return (
    <div>
      <h6>this is About Components</h6>
    </div>
  );
}

export default About;
