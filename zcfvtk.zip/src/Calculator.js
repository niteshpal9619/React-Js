function Calculator({ Total }) {
  return <div>{Total}</div>;
}

export default Calculator;
