import "./App.css";
import Home from "./Home.js";
import About from "./About.js";

let ShowValue = "About";
function Render() {
  if (ShowValue === "Home") {
    return <Home />;
  } else {
    return <About />;
  }
}

function App() {
  return (
    <div className="App">
      <Render />
    </div>
  );
}

export default App;
