function Para({ name, bgColor }) {
  return (
    <div>
      <h1 style={{ backgroundColor: bgColor }}>{name}</h1>
    </div>
  );
}

export default Para;
