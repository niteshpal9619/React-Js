import Card from "./Card";
import "./App.css";

function App({ Header, Content, Footer }) {
  return (
    <div className="Main">
      <Card
        Header="John Doe Details"
        Content="https://loremflickr.com/235/230"
        Footer="John Doe"
      ></Card>
      &nbsp;&nbsp;&nbsp;
      <Card
        Header="Krishna Sager Details"
        Content="https://loremflickr.com/236/230"
        Footer="Krishna Sager"
      ></Card>
      &nbsp;&nbsp;&nbsp;
      <Card
        Header="Kesar Details"
        Content="https://loremflickr.com/235/230"
        Footer="Gowanda Gupta"
      ></Card>
      &nbsp;&nbsp;&nbsp;
      <Card
        Header="Shree Details"
        Content="https://loremflickr.com/236/230"
        Footer="USA Sager"
      ></Card>
      &nbsp;&nbsp;&nbsp;
      <Card
        Header="Shree Details"
        Content="https://loremflickr.com/236/230"
        Footer="USA Sager"
      ></Card>
      &nbsp;&nbsp;&nbsp;
      <Card
        Header="Shree Details"
        Content="https://loremflickr.com/236/230"
        Footer="USA Sager"
      ></Card>
    </div>
  );
}

export default App;
